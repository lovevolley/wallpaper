# matrix
Matrix like animation using HTML5 Canvas. Inspired from [sample code](http://thecodeplayer.com/walkthrough/matrix-rain-animation-html5-canvas-javascript) on [thecodeplayer.com](http://thecodeplayer.com/).

See it in action @ http://parambirs.github.io/matrix

@ 2020-09-05 - added lively customizable options (rainbow / color select) - khuong